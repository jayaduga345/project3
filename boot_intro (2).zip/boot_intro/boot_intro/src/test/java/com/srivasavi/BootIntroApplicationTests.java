package com.srivasavi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootIntroApplicationTests {

	@Test
	void contextLoads() {
	}

}
