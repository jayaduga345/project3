package com.srivasavi.configure;

import org.springframework.context.annotation.Configuration;

@Configuration

public class FirstConfigure {
	public FirstConfigure()
	{
		System.out.println("inside FirstConfigure no-arg constructor");
	}
	public Thread getThread()
	{
		System.out.println("inside getThread");
		return new Thread();
	}

}
