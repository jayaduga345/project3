package com.srivasavi.repository;

public interface AddressRepository {

}
