package com.srivasavi.dto;

public class Address {

}
